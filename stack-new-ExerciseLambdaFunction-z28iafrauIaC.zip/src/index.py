import json
import boto3
import cfnresponse

s3 = boto3.client('s3')
ssm = boto3.client('ssm')

def handler(event, context):
    response_data = {}
    try:
        if event['RequestType'] == 'Delete':
            cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data)
            return

        parameter_name = 'UserName'
        parameter = ssm.get_parameter(Name=parameter_name)
        parameter_value = parameter['Parameter']['Value']

        s3.put_object(
            Bucket='bucket-2024',
            Key='parameter.txt',
            Body=parameter_value
        )

        response_data['Status'] = 'Success'
        cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data)
    except Exception as e:
        response_data['Error'] = str(e)
        cfnresponse.send(event, context, cfnresponse.FAILED, response_data)
